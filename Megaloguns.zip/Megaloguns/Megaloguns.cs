using Terraria.ModLoader;

namespace Megaloguns
{
	class Megaloguns : Mod
	{
		public Megaloguns()
		{
		}
	}
}
